import { Component } from '@angular/core';
import { Iemployee } from './employee';
import { EmployeeService } from './display-emp/emp.service';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular-get-started';
}



 




