import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { RequestOptions,Headers } from '@angular/http';
import { Observable } from "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Iemployee } from '../employee';



@Injectable()
export class EmployeeService {
   private _getAllEmpUrl='http://localhost:8080/api/employee/list';
   private _createEmpUrl='http://localhost:8080/api/employee';
   private _getEmp='http://localhost:8080/api/employee/';
   constructor(private _http: Http){}
   
   getAllEmployees(): Observable<Iemployee[]> {
      return this._http.get(this._getAllEmpUrl)
      .map((response: Response) => <Iemployee[]> response.json())
      .do(data => console.log('HI.......'+ JSON.stringify(data)));
   }

   //getEmployee()
   createEmployee(employeeData:Iemployee): Observable<Iemployee> {
   	let headers = new Headers({ 'Content-Type': 'application/json' });
   	let options = new RequestOptions({ headers: headers });

   	 return this._http.post(this._createEmpUrl,employeeData,options)
   	 .map((response : Response) => <Iemployee> response.json())
   	 .do(data => console.log('Employee added succesfully'+ JSON.stringify(data)));

   }
   /*updateEmployee()
   deleteEmployee()*/
   private extractData(res: Response) {
	let body = res.json();
        return body || {};
    }

}