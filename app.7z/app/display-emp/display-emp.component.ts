import { Component, OnInit } from '@angular/core';
import { Iemployee } from '../employee';
import { EmployeeService } from '../display-emp/emp.service';
import { Http , Response } from '@angular/http';
import { Observable } from "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';

@Component({
  selector: 'app-display-emp',
  templateUrl: './display-emp.component.html',
  styleUrls: ['./display-emp.component.scss'],
  providers : [EmployeeService]
})
export class DisplayEmpComponent {

	emplist : Iemployee[];

	constructor(private _empService : EmployeeService) {}

	ngOnInit() : void {

		this._empService.getAllEmployees().subscribe(
			emplist=>
			this.emplist = emplist
		);
		console.log('in comp...');
	}


}
