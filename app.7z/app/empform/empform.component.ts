import { Component, OnInit } from '@angular/core';
import { Iemployee } from '../employee';
import { EmployeeService } from '../display-emp/emp.service';
import { Http , Response } from '@angular/http';
import { Observable } from "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';

@Component({
  selector: 'app-empform',
  templateUrl: './empform.component.html',
  styleUrls: ['./empform.component.scss'],
  providers : [EmployeeService]
})
export class EmpformComponent {

emp = new Iemployee();

firstname : string;
  constructor(private _empService : EmployeeService) { }

  /*ngOnInit(): void{
  	this.createEmployee();
  }*/

  createEmployee(): void {
  	console.log('hi........');
  	this._empService.createEmployee(this.emp)
  	.subscribe( employeeData => {
  		this.firstname = employeeData.first_name;
  		}
  	);

  }
}
