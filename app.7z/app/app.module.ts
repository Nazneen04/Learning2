import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeroFormComponent } from './hero-form/hero-form.component';
import { EmpformComponent } from './empform/empform.component';
import { EmployeeService } from './display-emp/emp.service';
import { DisplayEmpComponent } from './display-emp/display-emp.component';
import { HttpModule } from '@angular/http';
import { Http , Response } from '@angular/http';
import { Observable } from "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
@NgModule({
  declarations: [
    AppComponent,
    HeroFormComponent,
    EmpformComponent,
    DisplayEmpComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
